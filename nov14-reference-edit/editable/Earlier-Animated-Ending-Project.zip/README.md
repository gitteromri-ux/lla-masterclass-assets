# Julie Masterclass: Editable Ending

This package contains the rendered four-scene ending, its editable HyperFrames composition, original source assets and reproducible assembly script. No external post or ad publication is included.

## Source and edit scope

- **Base video:** The previously shared 90-second Ad#11, copied without modification to `assets/original-90-second-cut.mp4`. Its original image is 1280 × 720; the final composition is 1920 × 1080, so the original footage is upscaled rather than native 1080p.
- **New picture:** Four redesigned cards occupy 73.0–87.4 seconds. Julie's portrait, the learning/clock message, the November 14 schedule and the 90-minute VIP format appear in that order.
- **Audio:** The entire source AAC stream is copied unchanged. The card timing follows that existing closing audio; no separate music retiming, stem extraction, new track, speech loop or time stretching is applied.
- **Existing footage:** The first 73 seconds and original eTeacher/Enroll finish are retained. The source contains Blueprint/course references, including an 18-session offer; those were not rewritten. This source does not contain the duplicate “Learn to age slower” card described in the request, so no such earlier card was removed.
- **Runtime:** The final export is approximately 90.27 seconds. The last source frame is held briefly to cover the complete original audio tail.

## Editing

- **Timing and movement:** Edit `index.html`. Each card has independent graphic layers, start times and GSAP tweens. The composition is deterministic and uses a paused timeline.
- **Typography and copy:** Edit `rebuild-artwork.py`, then run `python rebuild-artwork.py` with Pillow and NumPy installed. Text is rasterized into separate high-resolution transparent layers to retain the precise approved lighting and font rendering; it is not editable as live text in Studio.
- **Artwork:** The original logo, clock and unchanged Julie portrait are in `source/`. The portrait is not AI altered.
- **Assembly:** Render `index.html` as `ending-motion.mp4`, then run `bash assemble.sh`. The assembly script needs FFmpeg and preserves the full source audio stream with `-c:a copy`.

## Rendering

The project was rendered locally with HyperFrames 0.8.173, Chromium and FFmpeg. With that version available, run:

```bash
hyperframes check . --snapshots
hyperframes render . --quality delivery --fps 30 --output ending-motion.mp4
bash assemble.sh
```

The local vendor script avoids a runtime CDN dependency. HyperFrames upstream license is retained in `upstream/LICENSE`.

## Verification boundaries

The initial HyperFrames check reported no errors and eight structural editing warnings: four scene containers lack the optional `clip` class and four layered scene containers could instead be sub-compositions. These do not block rendering. Text is supplied as image layers, so the automated DOM contrast audit does not measure the letterforms; visual frame review is required.

The source-selection limitation matters: Ad#11 is the available 90-second base used here, not independently verified as the user's intended “masterclass final.” This package must not be represented as confirmation that the requested duplicate-card removal or separate music retiming was performed.
