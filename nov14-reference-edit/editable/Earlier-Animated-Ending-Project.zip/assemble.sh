#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Render index.html with HyperFrames 0.8.173 first:
# hyperframes render --quality delivery --fps 30 --output ending-motion.mp4
# Preserve the entire original AAC stream without editing or re-encoding it.
ffmpeg -hide_banner -y \
  -i assets/original-90-second-cut.mp4 \
  -i ending-motion.mp4 \
  -filter_complex \
  "[0:v]scale=1920:1080:flags=lanczos,setsar=1,tpad=stop_mode=clone:stop_duration=0.134[base];[1:v]format=yuva420p,fade=t=in:st=0:d=0.333:alpha=1,fade=t=out:st=14.067:d=0.333:alpha=1,setpts=PTS+73/TB[cards];[base][cards]overlay=eof_action=pass:enable='between(t,73,87.4)'[out]" \
  -map "[out]" -map 0:a:0 \
  -c:v libx264 -preset fast -crf 17 -pix_fmt yuv420p -r 30 \
  -c:a copy -t 90.266667 -movflags +faststart \
  Julie-Masterclass-90s-New-Ending.mp4
