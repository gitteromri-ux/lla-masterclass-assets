#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python build.py
python urgent-fixes.py
ffmpeg -v error -y \
 -i source/masterclass-source.mp4 \
 -i scene-1.mp4 \
 -loop 1 -framerate 30 -i card-2.png \
 -loop 1 -framerate 30 -i card-3.png \
 -loop 1 -framerate 30 -i card-4.png \
 -loop 1 -framerate 30 -i card-5.png \
 -loop 1 -framerate 30 -i press-fixed.png \
 -loop 1 -framerate 30 -i automatic-cover.png \
 -i source/masterclass-source.mp4 \
 -filter_complex_threads 2 -filter_complex \
 "[0:v]trim=0:62.8,setpts=PTS-STARTPTS[vb];[vb][6:v]overlay=enable='between(t,9.666667,13.033333)'[vp];[vp][7:v]overlay=enable='between(t,53.683333,58.733333)',trim=0:62.8,setsar=1[v0];[1:v]trim=0:5.6,setpts=PTS-STARTPTS,setsar=1[c1];[2:v]trim=0:6,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[c2];[3:v]trim=0:6,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[c3];[4:v]trim=0:6,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[c4];[5:v]trim=0:5.5,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[c5];[c2][c3]xfade=transition=fade:duration=0.4:offset=5.6[c23];[c23][c4]xfade=transition=fade:duration=0.4:offset=11.2[c234];[c234][c5]xfade=transition=fade:duration=0.4:offset=16.8[c2345];[v0][c1][c2345]concat=n=3:v=1:a=0,trim=0:87.5[v];[8:a]atrim=0:62.8,asetpts=PTS-STARTPTS[body];[8:a]atrim=90:92.366667,asetpts=PTS-STARTPTS,volume=0.78[lead];[8:a]atrim=113.5:130.5,asetpts=PTS-STARTPTS[voice];[8:a]atrim=130.5:136.633333,asetpts=PTS-STARTPTS,aecho=0.8:0.75:700|1400|2200:0.4|0.25|0.14,apad,atrim=0:6.133333[tail];[voice][tail]concat=n=2:v=0:a=1[end];[lead][end]acrossfade=d=0.2:c1=qsin:c2=qsin[bed];[body][bed]acrossfade=d=0.1:c1=qsin:c2=qsin,alimiter=limit=0.89:level=false,apad,atrim=0:87.5,afade=t=out:st=86.8:d=0.7[a]" \
 -map "[v]" -map "[a]" -t 87.5 -r 30 -c:v libx264 -preset veryfast -crf 18 -threads 8 \
 -c:a aac -b:a 320k -ar 48000 -pix_fmt yuv420p -movflags +faststart \
 Julie-Masterclass-Nov14-Launch-Final.mp4
