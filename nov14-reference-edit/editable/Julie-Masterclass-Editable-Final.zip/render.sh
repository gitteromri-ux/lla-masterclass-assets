#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
DEFAULT_SOURCE=../julie-masterclass-film-long-masterclass-edit-1080p.mp4
[[ -f source/masterclass-source.mp4 ]] && DEFAULT_SOURCE=source/masterclass-source.mp4
SOURCE="${1:-$DEFAULT_SOURCE}"
python build.py
# Four six-second scenes and a 5.5-second enrollment finish.
# Dissolves overlap by 0.4 s. Final ending trimmed to 27.2 s; body is 62.8 s.
for n in 1 2 3 4 5; do
  frames=180; [[ "$n" == 5 ]] && frames=165
  ffmpeg -v error -y -loop 1 -i "card-$n.png" \
    -vf "scale=2048:1152,zoompan=z='1.001+0.00007*on':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s=1920x1080:fps=30,format=yuv420p" \
    -frames:v "$frames" -an -c:v libx264 -preset fast -crf 18 -threads 4 "scene-$n.mp4" &
done
wait
ffmpeg -v error -y -i scene-1.mp4 -i scene-2.mp4 -i scene-3.mp4 -i scene-4.mp4 -i scene-5.mp4 \
  -filter_complex_threads 2 -filter_complex \
  "[0:v][1:v]xfade=transition=fade:duration=0.4:offset=5.6[v1];[v1][2:v]xfade=transition=fade:duration=0.4:offset=11.2[v2];[v2][3:v]xfade=transition=fade:duration=0.4:offset=16.8[v3];[v3][4:v]xfade=transition=fade:duration=0.4:offset=22.4[v]" \
  -map "[v]" -an -c:v libx264 -preset fast -crf 18 -threads 6 -pix_fmt yuv420p ending.mp4
# Original soundtrack only, no repeated musical sections.
# Short instrumental lead joins the complete original closing speech and score.
ffmpeg -v error -y -i "$SOURCE" -filter_complex \
  "[0:a]atrim=0:62.8,asetpts=PTS-STARTPTS[body];[0:a]atrim=90:94.366667,asetpts=PTS-STARTPTS,volume=0.78[lead];[0:a]atrim=113.5:136.633333,asetpts=PTS-STARTPTS[end];[lead][end]acrossfade=d=0.2:c1=qsin:c2=qsin,afade=t=out:st=26.1:d=1.2[bed];[body][bed]acrossfade=d=0.1:c1=qsin:c2=qsin,alimiter=limit=0.89:level=false,apad,atrim=0:90[aout]" \
  -map "[aout]" -ar 48000 -c:a pcm_s24le soundtrack.wav
ffmpeg -v error -y -i "$SOURCE" -i ending.mp4 -i soundtrack.wav \
  -filter_complex_threads 2 -filter_complex \
  "[0:v]trim=0:62.8,setpts=PTS-STARTPTS,fps=30,setsar=1[v0];[1:v]trim=0:27.2,setpts=PTS-STARTPTS,setsar=1[v1];[v0][v1]concat=n=2:v=1:a=0[v]" \
  -map "[v]" -map 2:a -t 90 -c:v libx264 -crf 18 -preset veryfast -threads 8 \
  -c:a aac -b:a 320k -ar 48000 -pix_fmt yuv420p -movflags +faststart \
  Julie-Masterclass-90s-Reference-Card-Edit.mp4
