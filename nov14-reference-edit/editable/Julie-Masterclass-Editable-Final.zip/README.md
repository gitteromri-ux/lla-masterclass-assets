# Julie Masterclass: November 14 Launch Cut

The latest export is `Julie-Masterclass-Nov14-Launch-Final.mp4`, 87.5 seconds. It is based on the prior new cut from the verified long masterclass film, with the five timestamped corrections requested for launch.

## Launch corrections

- The complete original AUTOMATIC / like brushing your teeth card covers 53.683333–58.733333 seconds. The early card entrance removes the two-frame AirPod flash; the extended hold covers the inconsistent ear/microphone shot, including a residual AirPod frame found at 58.433333, without altering Julie's face or the spoken audio.
- Card 1 cuts cleanly to Card 2 at 68.400 seconds. Cards 2–5 share a fixed 460-pixel logo at Y=70, without zoom movement.
- The closing voiceover starts two seconds earlier than in the preceding edit.
- The instrumental closing tail has a restrained delayed reverb and final fade, and the export ends at 87.500 seconds rather than 90.
- The Fortune and Business Insider dates are relocated above the overlapping Yahoo card, using the complete dates visible in the unobstructed source frame.

To reproduce the latest version, run `bash urgent-render.sh`. The earlier `render.sh` is retained for the previous 90-second edit.

## Source and edit

- **Masterclass source:** the 136.63-second film from the [masterclass film gallery](https://gitteromri-ux.github.io/lla-masterclass-assets/julie-film-v4/).
- **Opening:** source 00:00–01:02.800. The cut follows “not intensity, but repetition that never quits,” before the next spoken introduction.
- **Closing:** four newly rendered, reference-led cards and an enrollment finish. The clock appears only on the slow-aging card. The original later slow-aging card and outdated offer/date cards are outside the retained source range.
- **Event text:** Saturday, Nov 14th; 12 PM ET. Duration is marked as a VIP experience.
- **Portrait:** the original smiling Julie site photograph, composited without face generation or alteration.
- **Music and closing speech:** only original audio, with no repeated musical sections and no tempo change. A short instrumental lead from 01:30 joins the complete original closing narration and score from 01:53.500. The final fade runs from 01:26.800 to 01:27.500. No new score or voice was generated.
- **Publication:** GitHub download and editable handoff as authorized. No social post, ad, or production website was changed.

## Editable contents

`build.py` contains all card text, font choices, positions, lighting, and image compositing. `urgent-render.sh` contains the latest scene durations, transitions, source cut points, audio crossfades, and encoding settings. `render.sh` is retained for the superseded 90-second version.

`card-1.png` through `card-5.png` are lossless 1920×1080 artwork. `text-bounds.json` records measured lettering bounds. The contact sheet and phone proof are review images, not a replacement for the integrated video.

To rebuild in this workspace:

```sh
bash urgent-render.sh
```

Dependencies: Python, Pillow, NumPy, FFmpeg, the included fonts and original images. The archive includes the source film and original images for portability; `build.py` can use the bundled source directory.

## Verification boundary

Runtime, decoding, frame geometry, text placement, and soundtrack measurements are checked mechanically. Visual frames and audio are reviewed separately. No claim of user approval or performance improvement is made.
