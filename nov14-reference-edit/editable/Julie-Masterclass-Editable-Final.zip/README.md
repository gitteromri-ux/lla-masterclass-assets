# Julie Masterclass: 90-Second Reference-Card Edit

This is a new 90-second edit from the verified long masterclass film. It is not the rejected Ad#11 Blueprint edit, and it is not represented as a recovered pre-existing 90-second master.

## Source and edit

- **Masterclass source:** the 136.63-second film from the [masterclass film gallery](https://gitteromri-ux.github.io/lla-masterclass-assets/julie-film-v4/).
- **Opening:** source 00:00–01:02.800. The cut follows “not intensity, but repetition that never quits,” before the next spoken introduction.
- **Closing:** four newly rendered, reference-led cards and an enrollment finish. The clock appears only on the slow-aging card. The original later slow-aging card and outdated offer/date cards are outside the retained source range.
- **Event text:** Saturday, Nov 14th; 12 PM ET. Duration is marked as a VIP experience.
- **Portrait:** the original smiling Julie site photograph, composited without face generation or alteration.
- **Music:** only audio from the same masterclass film. A clean 7.5-second instrumental phrase at 01:30 is repeated with 0.5-second crossfades and increasing level, joined to the final instrumental tail at 02:11. The resulting bed is slowed by approximately 2.4% without pitch shift and faded over its final 1.2 seconds. No new score or voice was generated.
- **Publication:** local deliverables only. Nothing was posted or deployed.

## Editable contents

`build.py` contains all card text, font choices, positions, lighting, and image compositing. `render.sh` contains all scene durations, transitions, source cut points, music loop points, crossfades, and encoding settings.

`card-1.png` through `card-5.png` are lossless 1920×1080 artwork. `text-bounds.json` records measured lettering bounds. The contact sheet and phone proof are review images, not a replacement for the integrated video.

To rebuild in this workspace:

```sh
bash render.sh /absolute/path/to/julie-masterclass-film-long-masterclass-edit-1080p.mp4
```

Dependencies: Python, Pillow, NumPy, FFmpeg, the included fonts and original images. The archive includes the source film and original images for portability; `build.py` can use the bundled source directory.

## Verification boundary

Runtime, decoding, frame geometry, text placement, and soundtrack measurements are checked mechanically. Visual frames and audio are reviewed separately. No claim of user approval or performance improvement is made.
