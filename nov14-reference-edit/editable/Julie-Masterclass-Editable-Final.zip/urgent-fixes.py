from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
P=Path(__file__).resolve().parent
im=Image.open(P/'press-later.png').convert('RGB')
d=ImageDraw.Draw(im)
# Relocate the dates into the open space above the overlapping Yahoo card.
# Dates are copied from the unobstructed source frame at 9.4 seconds.
d.rectangle((450,518,512,560),fill=(14,22,40))
d.rectangle((1410,537,1620,583),fill=(14,22,40))
f=ImageFont.truetype(str(P/'source/fonts/Inter.ttf'),24)
d.text((454,454),'November 4, 2023',font=f,fill=(203,211,226),anchor='lt')
d.text((1374,454),'November 6, 2023',font=f,fill=(203,211,226),anchor='lt')
im.save(P/'press-fixed.png')
