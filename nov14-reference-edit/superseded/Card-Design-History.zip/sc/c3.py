from PIL import Image, ImageDraw, ImageFont, ImageFilter
W,H=1920,1080
F='/home/user/fonts/'
R=lambda s:ImageFont.truetype(F+'InstrumentSerif-Regular.ttf',s)
I=lambda s:ImageFont.truetype(F+'InstrumentSerif-Italic.ttf',s)
inter=ImageFont.truetype(F+'Inter.ttf',62); inter.set_variation_by_axes([32,700])
# deep navy bg with brighter central glow
bg=Image.new('RGB',(W,H),(4,8,22))
g=Image.new('L',(W,H),0); ImageDraw.Draw(g).ellipse((260,180,1660,980),fill=255); g=g.filter(ImageFilter.GaussianBlur(220))
bg=Image.composite(Image.new('RGB',(W,H),(22,44,96)),bg,g)
d=ImageDraw.Draw(bg)
logo=Image.open('logo.png').convert('RGBA'); lw=420; logo=logo.resize((lw,int(logo.height*lw/logo.width)),Image.LANCZOS)
bg.paste(logo,((W-lw)//2,40),logo)
y0=40+logo.height+45
def ctext(t,f,y,fill,shadow=True):
    w=d.textlength(t,font=f); x=(W-w)/2
    if shadow:
        s=Image.new('RGBA',(W,H),(0,0,0,0)); ImageDraw.Draw(s).text((x,y),t,font=f,fill=(0,0,0,200)); s=s.filter(ImageFilter.GaussianBlur(10)); bg.paste(s,(0,4),s)
    d.text((x,y),t,font=f,fill=fill)
GOLD=(255,206,110); WHITE=(255,255,255); CYAN=(120,220,255)
ctext('LONGEVITY MASTERCLASS OF THE YEAR',inter,y0,GOLD)
# rule pair
d.line((W/2-420,y0+100,W/2+420,y0+100),fill=GOLD,width=3)
ctext('Nov 14th',R(330),y0+105,WHITE)
ctext('12 PM ET · Live on Zoom.',I(120),y0+500,CYAN)
bg.save('v4card3.png')
