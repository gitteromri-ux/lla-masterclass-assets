from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops
W,H=1920,1080;F='/home/user/fonts/'
R=lambda s:ImageFont.truetype(F+'InstrumentSerif-Regular.ttf',s)
I=lambda s:ImageFont.truetype(F+'InstrumentSerif-Italic.ttf',s)
inter=ImageFont.truetype(F+'Inter.ttf',30);inter.set_variation_by_axes([32,500])
bg=Image.new('RGB',(W,H),(1,3,10))
g=Image.new('L',(W,H),0);ImageDraw.Draw(g).ellipse((300,200,1620,960),fill=255);g=g.filter(ImageFilter.GaussianBlur(220))
bg=Image.composite(Image.new('RGB',(W,H),(12,28,70)),bg,g).convert('RGBA')
GOLD=(214,182,120)
def tw(t,f):
    b=f.getbbox(t);return b[2]-b[0],b
def mask_text(t,f,y,track=0):
    m=Image.new('L',(W,H),0);dm=ImageDraw.Draw(m)
    if track:
        ws=[dm.textlength(ch,font=f)+track for ch in t];x=(W-sum(ws)+track)/2
        for ch,w in zip(t,ws):dm.text((x,y),ch,font=f,fill=255);x+=w
    else:
        w=dm.textlength(t,font=f);dm.text(((W-w)/2,y),t,font=f,fill=255)
    return m
def gold_grad(m):
    bb=m.getbbox();gr=Image.new('RGB',(W,H))
    dg=ImageDraw.Draw(gr);y0,y1=bb[1],bb[3]
    stops=[(0,(255,240,200)),(0.45,(232,196,128)),(0.55,(196,150,82)),(1,(246,220,160))]
    for y in range(y0,y1+1):
        t=(y-y0)/max(1,y1-y0)
        for i in range(len(stops)-1):
            if stops[i][0]<=t<=stops[i+1][0]:
                a=(t-stops[i][0])/(stops[i+1][0]-stops[i][0]);c=tuple(int(stops[i][1][k]*(1-a)+stops[i+1][1][k]*a) for k in range(3))
        dg.line((0,y,W,y),fill=c)
    return gr
def paste_glow(m,color,blur,alpha):
    gl=m.filter(ImageFilter.GaussianBlur(blur)).point(lambda v:int(v*alpha))
    bg.alpha_composite(Image.merge('RGBA',(*[Image.new('L',(W,H),c) for c in color],gl)))
def shadow(m):
    s=m.filter(ImageFilter.GaussianBlur(12)).point(lambda v:int(v*0.7))
    s=ImageChops.offset(s,0,6);bg.alpha_composite(Image.merge('RGBA',(Image.new('L',(W,H),0),)*3+(s,)))
# frame
d=ImageDraw.Draw(bg)
d.rectangle((48,48,W-48,H-48),outline=GOLD+(150,),width=2)
d.rectangle((60,60,W-60,H-60),outline=GOLD+(70,),width=1)
logo=Image.open('logo.png').convert('RGBA');lw=300;logo=logo.resize((lw,int(logo.height*lw/logo.width)),Image.LANCZOS)
bg.alpha_composite(logo,((W-lw)//2,92))
# headline gold shine
y=92+logo.height+34
m=mask_text('Longevity Masterclass of the Year',R(124),y)
shadow(m);paste_glow(m,(255,210,140),26,0.55)
bg.alpha_composite(Image.merge('RGBA',(*gold_grad(m).split(),m)))
# ornament rule
cy=y+172;d=ImageDraw.Draw(bg)
d.line((W/2-330,cy,W/2-22,cy),fill=GOLD+(255,),width=2);d.line((W/2+22,cy,W/2+330,cy),fill=GOLD+(255,),width=2)
d.polygon([(W/2,cy-9),(W/2+9,cy),(W/2,cy+9),(W/2-9,cy)],fill=GOLD+(255,))
# date
m=mask_text('Nov 14th',R(320),cy+10);shadow(m);paste_glow(m,(150,190,255),40,0.35)
bg.alpha_composite(Image.merge('RGBA',(Image.new('L',(W,H),252),Image.new('L',(W,H),253),Image.new('L',(W,H),255),m)))
m=mask_text('Saturday  ·  12 PM ET  ·  Live on Zoom',I(84),cy+392);shadow(m)
bg.alpha_composite(Image.merge('RGBA',(Image.new('L',(W,H),200),Image.new('L',(W,H),216),Image.new('L',(W,H),255),m)))
bg.convert('RGB').save('v6card3.png');bg.convert('RGB').save('/home/user/workspace/fb/card3-date-official-v6.jpg',quality=93)
