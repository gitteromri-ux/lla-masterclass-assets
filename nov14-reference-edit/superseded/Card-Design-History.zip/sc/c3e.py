from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops
W,H=1920,1080;F='/home/user/fonts/'
R=lambda s:ImageFont.truetype(F+'InstrumentSerif-Regular.ttf',s)
I=lambda s:ImageFont.truetype(F+'InstrumentSerif-Italic.ttf',s)
L=lambda v:Image.new('L',(W,H),v)
bg=Image.new('RGB',(W,H),(1,3,10))
g=Image.new('L',(W,H),0);ImageDraw.Draw(g).ellipse((280,160,1640,980),fill=255);g=g.filter(ImageFilter.GaussianBlur(230))
bg=Image.composite(Image.new('RGB',(W,H),(6,16,44)),bg,g).convert('RGBA')
# soft top light beam
b=Image.new('L',(W,H),0);ImageDraw.Draw(b).polygon([(W/2-120,0),(W/2+120,0),(W/2+560,H),(W/2-560,H)],fill=34);b=b.filter(ImageFilter.GaussianBlur(120))
bg.alpha_composite(Image.merge('RGBA',(L(120),L(170),L(255),b)))
def mt(t,f,y):
    m=Image.new('L',(W,H),0);dm=ImageDraw.Draw(m);w=dm.textlength(t,font=f);dm.text(((W-w)/2,y),t,font=f,fill=255);return m
def grad(m,stops):
    bb=m.getbbox();gr=Image.new('RGB',(W,H));dg=ImageDraw.Draw(gr)
    for y in range(bb[1],bb[3]+1):
        t=(y-bb[1])/max(1,bb[3]-bb[1])
        for i in range(len(stops)-1):
            if stops[i][0]<=t<=stops[i+1][0]:
                a=(t-stops[i][0])/(stops[i+1][0]-stops[i][0]);c=tuple(int(stops[i][1][k]*(1-a)+stops[i+1][1][k]*a) for k in range(3))
        dg.line((0,y,W,y),fill=c)
    return gr
def glow(m,col,blur,a):
    bg.alpha_composite(Image.merge('RGBA',(L(col[0]),L(col[1]),L(col[2]),m.filter(ImageFilter.GaussianBlur(blur)).point(lambda v:int(v*a))))) 
def shadow(m):
    s=ImageChops.offset(m.filter(ImageFilter.GaussianBlur(14)).point(lambda v:int(v*.75)),0,6);bg.alpha_composite(Image.merge('RGBA',(L(0),L(0),L(0),s)))
logo=Image.open('logo.png').convert('RGBA');lw=300;logo=logo.resize((lw,int(logo.height*lw/logo.width)),Image.LANCZOS)
bg.alpha_composite(logo,((W-lw)//2,70))
y=70+logo.height+44
m=mt('Longevity Masterclass of the Year',R(128),y)
shadow(m);glow(m,(90,160,240),60,.9);glow(m,(122,184,240),24,1.0);glow(m,(190,225,255),8,.6)
bg.alpha_composite(Image.merge('RGBA',(*grad(m,[(0,(214,236,255)),(.38,(150,200,246)),(.5,(122,182,238)),(.56,(236,246,255)),(.66,(126,186,240)),(1,(98,160,226))]).split(),m)))
# platinum-blue rule fading at ends
cy=y+178;rl=Image.new('L',(W,H),0);dr=ImageDraw.Draw(rl)
for x in range(int(W/2-360),int(W/2+360)):
    dr.line((x,cy-1,x,cy+1),fill=int(255*(1-abs(x-W/2)/360)**.6))
bg.alpha_composite(Image.merge('RGBA',(L(140),L(196),L(240),rl)))
m=mt('Nov 14th',R(330),cy+6);shadow(m);glow(m,(120,175,255),46,.45)
bg.alpha_composite(Image.merge('RGBA',(L(253),L(254),L(255),m)))
m=mt('Saturday  ·  12 PM ET  ·  Live on Zoom',I(86),cy+396);shadow(m)
bg.alpha_composite(Image.merge('RGBA',(L(236),L(240),L(248),m)))
bg.convert('RGB').save('v8card3.png');bg.convert('RGB').save('/home/user/workspace/fb/card3-date-premium-v8.jpg',quality=93)
