import sys
CSS=open('../html/base.css').read()
def page(name,photo,pos,size,left,grade,fadestop):
    h=f'''<!doctype html><html><head><meta charset="utf-8"><style>{CSS}
.ph{{position:absolute;top:0;left:{left}px;right:0;height:1080px;background:url(../../julie/{photo}) {pos}/{size} no-repeat;filter:{grade}}}
.tint{{position:absolute;inset:0;background:linear-gradient(180deg,#0B2350,#061433);mix-blend-mode:color;opacity:.38}}
.fade{{position:absolute;inset:0;background:linear-gradient(90deg,#030817 0%,#030817 {fadestop}%,rgba(3,8,23,.85) {fadestop+8}%,rgba(3,8,23,.35) {fadestop+20}%,rgba(3,8,23,0) {fadestop+34}%),linear-gradient(0deg,rgba(3,8,23,.7),rgba(3,8,23,0) 30%),linear-gradient(180deg,rgba(3,8,23,.45),rgba(3,8,23,0) 22%)}}
.glow{{position:absolute;inset:0;background:radial-gradient(ellipse 45% 60% at 22% 55%,rgba(40,90,170,.22),rgba(0,0,0,0) 70%)}}
.col{{position:absolute;left:128px;top:0;bottom:0;width:980px;display:flex;flex-direction:column}}
.lg{{margin-top:70px;width:520px;margin-left:-8px;filter:drop-shadow(0 6px 24px rgba(0,0,0,.6))}}
.t{{flex:1;display:flex;flex-direction:column;justify-content:center;padding-bottom:40px}}
.l1,.l2{{font-family:PFR;font-weight:400;font-size:136px;line-height:1.02;letter-spacing:-1px;color:#fff;text-shadow:0 10px 30px rgba(0,0,0,.6)}}
.l3{{font-family:PF;font-size:136px;line-height:1.1;color:#9CC8F2;text-shadow:0 0 30px rgba(143,192,238,.35),0 10px 30px rgba(0,0,0,.6)}}
.bar{{width:96px;height:3px;background:#8FC0EE;margin:54px 0 34px}}
.nm{{font-family:Codec;font-size:50px;letter-spacing:12px;color:#fff;text-transform:uppercase}}
</style></head><body><div class="layer navy"></div><div class="ph"></div><div class="tint"></div><div class="fade"></div><div class="glow"></div><div class="layer grain"></div>
<div class="col"><img class="lg" src="../logo.png"><div class="t"><div class="l1">Longevity</div><div class="l2">Masterclass</div><div class="l3">of the Year</div><div class="bar"></div><div class="nm">Julie Gibson Clark</div></div></div></body></html>'''
    open(name+'.html','w').write(h)
page('a','julie-goldenhour-crop.jpg','50% 30%','auto 1080px',560,'saturate(.7) contrast(1.06) brightness(.95)',28)
page('b','julie-portrait.jpg','50% 12%','cover',640,'saturate(.55) contrast(1.05) brightness(.92)',30)
page('c','julie-standing-hd.jpg','50% 18%','cover',900,'saturate(.65) contrast(1.06) brightness(.95)',44)
