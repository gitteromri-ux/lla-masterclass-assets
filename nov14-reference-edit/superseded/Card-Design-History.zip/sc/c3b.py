from PIL import Image, ImageDraw, ImageFont, ImageFilter
W,H=1920,1080;F='/home/user/fonts/'
R=lambda s:ImageFont.truetype(F+'InstrumentSerif-Regular.ttf',s)
I=lambda s:ImageFont.truetype(F+'InstrumentSerif-Italic.ttf',s)
bg=Image.new('RGB',(W,H),(1,3,10))
g=Image.new('L',(W,H),0);ImageDraw.Draw(g).ellipse((360,240,1560,900),fill=255);g=g.filter(ImageFilter.GaussianBlur(200))
bg=Image.composite(Image.new('RGB',(W,H),(10,24,62)),bg,g);d=ImageDraw.Draw(bg)
logo=Image.open('logo.png').convert('RGBA');lw=330;logo=logo.resize((lw,int(logo.height*lw/logo.width)),Image.LANCZOS)
bg.paste(logo,((W-lw)//2,36),logo)
def c(t,f,y,fill):
    w=d.textlength(t,font=f);x=(W-w)/2
    s=Image.new('RGBA',(W,H),(0,0,0,0));ImageDraw.Draw(s).text((x,y),t,font=f,fill=(0,0,0,170));s=s.filter(ImageFilter.GaussianBlur(14));bg.paste(s,(0,6),s)
    d.text((x,y),t,font=f,fill=fill)
WHITE=(250,251,255);BLUE=(190,210,255);GOLD=(201,170,112)
y=36+logo.height+40
c('Longevity Masterclass of the Year.',R(118),y,WHITE)
d.line((W/2-300,y+165,W/2+300,y+165),fill=GOLD,width=3)
c('Nov 14th',R(330),y+170,WHITE)
c('12 PM ET · Live on Zoom.',I(118),y+540,BLUE)
bg.save('v5card3.png');bg.save('/home/user/workspace/fb/card3-date-brand-v5.jpg',quality=92)
