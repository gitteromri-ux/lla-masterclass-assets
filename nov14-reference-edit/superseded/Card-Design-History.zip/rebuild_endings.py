from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
from pathlib import Path

ROOT=Path('/home/user/workspace/fb')
OUT=ROOT/'ending-rebuild'
OUT.mkdir(exist_ok=True)
W,H=1920,1080
BLUE=(169,207,245)
WHITE=(247,250,255)
FONTS=Path('/home/user/fonts')
def font(size,italic=False,sans=False):
    name='Inter.ttf' if sans else ('PlayfairDisplay-Italic.ttf' if italic else 'PlayfairDisplay.ttf')
    f=ImageFont.truetype(str(FONTS/name),size)
    try: f.set_variation_by_axes([400])
    except Exception: pass
    return f

def base():
    yy,xx=np.mgrid[0:H,0:W]
    a=np.exp(-(((xx-940)/970)**2+((yy-460)/740)**2)*2)
    b=np.exp(-(((xx-1400)/430)**2+((yy-40)/160)**2)*2)
    arr=np.zeros((H,W,3))
    for c,(v,g) in enumerate([(3,10),(8,23),(21,43)]):
        arr[:,:,c]=v+a*g+b*15
    return Image.fromarray(np.uint8(arr)).convert('RGBA')

def photo(img,path,box,focus=(.5,.5),strength=1):
    p=Image.open(path).convert('RGBA')
    x,y,w,h=box
    scale=max(w/p.width,h/p.height)
    p=p.resize((round(p.width*scale),round(p.height*scale)),Image.Resampling.LANCZOS)
    l=round((p.width-w)*focus[0]);t=round((p.height-h)*focus[1])
    p=p.crop((l,t,l+w,t+h))
    img.alpha_composite(p,(x,y))

def scrim(img,left_end=.45,fade_end=.70):
    yy,xx=np.mgrid[0:H,0:W]
    a=1-np.clip((xx/W-left_end)/(fade_end-left_end),0,1)
    bottom=np.clip((yy/H-.75)/.25,0,1)*.7
    a=np.maximum(a,bottom)
    lay=np.zeros((H,W,4),dtype=np.uint8)
    lay[:,:,:3]=(3,9,24)
    lay[:,:,3]=(a*255).astype(np.uint8)
    img.alpha_composite(Image.fromarray(lay))

def topfade(img):
    arr=np.zeros((H,W,4),dtype=np.uint8);arr[:,:,:3]=(3,9,24)
    arr[:,:,3]=(np.clip(1-np.arange(H)[:,None]/180,0,1)*255).astype(np.uint8)
    img.alpha_composite(Image.fromarray(arr))

def light(img,x=650,y=480,sx=700,sy=450,amount=.17):
    yy,xx=np.mgrid[0:H,0:W]
    a=np.exp(-(((xx-x)/sx)**2+((yy-y)/sy)**2)*2)*amount
    lay=np.zeros((H,W,4),dtype=np.uint8);lay[:,:,:3]=(110,170,239);lay[:,:,3]=(a*255).astype(np.uint8)
    img.alpha_composite(Image.fromarray(lay))

BOUNDS=[]
CARD=1
def text(img,words,x,y,size,color=WHITE,italic=False,sans=False,align='left',glow=.35):
    if not BOUNDS:
        img.save(OUT/f'background-{CARD}.png')
    textout=Image.new('RGBA',(W,H))
    f=font(size,italic,sans)
    d=ImageDraw.Draw(img)
    width=d.textlength(words,font=f)
    if align=='center': x-=width/2
    elif align=='right': x-=width
    mask=Image.new('L',(W,H))
    md=ImageDraw.Draw(mask);md.text((x,y),words,font=f,fill=255,anchor='lt')
    bb=mask.getbbox()
    BOUNDS.append(dict(text=words,bounds=bb,size=size))
    # Two-scale lighting, separate from crisp glyphs.
    for radius,opacity in [(42,glow*.4),(13,glow*.7)]:
        blur=mask.filter(ImageFilter.GaussianBlur(radius)).point(lambda a:int(a*opacity))
        lay=Image.new('RGBA',(W,H),(*color,0));lay.putalpha(blur);img.alpha_composite(lay);textout.alpha_composite(lay)
    # A restrained white-to-brand-blue lighting gradient on the letterforms.
    arr=np.zeros((H,W,4),dtype=np.uint8)
    if bb:
        top,bot=bb[1],bb[3]
        mix=np.clip((np.arange(H)-top)/max(1,bot-top),0,1)
        for c in range(3):
            arr[:,:,c]=np.round(color[c]+(255-color[c])*(1-mix[:,None])*.35)
    arr[:,:,3]=np.asarray(mask)
    img.alpha_composite(Image.fromarray(arr))
    textout.alpha_composite(Image.fromarray(arr))
    textout.save(OUT/f'text-{CARD}-{len(BOUNDS)}.png')
    return width

def logo(img,x=152,y=96):
    p=Image.open(ROOT/'sc/logo.png').convert('RGBA')
    # Crop only transparent pixels, preserve the exact official artwork.
    p=p.crop(p.getbbox())
    p=p.resize((480,round(p.height*480/p.width)),Image.Resampling.LANCZOS)
    img.alpha_composite(p,(x,y))

def line(img,x1,y,x2):
    m=Image.new('RGBA',(W,H));d=ImageDraw.Draw(m)
    d.line((x1,y,x2,y),fill=(*BLUE,160),width=2)
    img.alpha_composite(m.filter(ImageFilter.GaussianBlur(7)))
    img.alpha_composite(m)

def save(img,n):
    global CARD
    # 150px bottom exclusion zone; no copy may enter it.
    for b in BOUNDS:
        assert b['bounds'] and b['bounds'][0]>=120 and b['bounds'][2]<=1800, b
        assert b['bounds'][3]<=920, b
    img.convert('RGB').save(OUT/f'card-{n}.jpg',quality=96,subsampling=0)
    import json
    (OUT/f'card-{n}-bounds.json').write_text(json.dumps(BOUNDS,indent=2))
    BOUNDS.clear()
    CARD+=1

# Portrait: original site photograph, no generated facial details.
im=base()
photo(im,ROOT/'julie/julie-lifestyle.jpg',(470,0,1450,1080),focus=(0,0))
topfade(im)
scrim(im,.40,.67)
light(im,500,470,780,660,.13)
logo(im)
text(im,'Longevity',152,345,132)
text(im,'Masterclass',152,491,132)
text(im,'of the Year',152,640,132,BLUE,italic=True,glow=.5)
text(im,'Julie Gibson Clark',158,821,70,WHITE,sans=True,glow=.16)
save(im,1)

# Clock: large two-line message, distinct secondary copy, clock remains visible.
im=base()
photo(im,ROOT/'sc/clock4k.png',(500,0,1420,1080),focus=(.70,.5))
scrim(im,.30,.83)
light(im,520,510,720,650,.12)
logo(im)
text(im,'Learn to',152,345,148)
text(im,'age slower',145,505,172,BLUE,italic=True,glow=.6)
text(im,"from the world’s",158,733,84,WHITE,sans=True,glow=.2)
text(im,'2nd slowest ager',158,836,84,BLUE,sans=True,glow=.35)
save(im,2)

# Date: title and schedule have separate generous columns, no micro eyebrow.
im=base();light(im,1350,480,800,570,.15);logo(im)
d=ImageDraw.Draw(im);d.line((944,388,944,844),fill=(126,177,231,110),width=2)
line(im,1050,682,1740)
text(im,'Longevity',152,402,112)
text(im,'Masterclass',152,536,112)
text(im,'of the Year',152,678,112,BLUE,italic=True,glow=.5)
text(im,'Saturday',1050,376,86,BLUE,sans=True)
text(im,'Nov 14th',1040,496,144,WHITE,glow=.5)
text(im,'12 PM ET',1050,733,118,BLUE,glow=.55)
save(im,3)

# Format: the duration is a graphic anchor, not another long italic sentence.
im=base();light(im,600,500,840,650,.19);logo(im)
d=ImageDraw.Draw(im);d.line((806,403,806,852),fill=(126,177,231,110),width=2)
text(im,'90',148,367,430,BLUE,glow=.45)
text(im,'minutes',177,726,88,WHITE,sans=True)
text(im,'VIP experience',908,390,72,BLUE,sans=True,glow=.3)
text(im,'Masterclass',898,532,116,WHITE,glow=.45)
text(im,'+ live Q&A',898,704,116,BLUE,glow=.55)
save(im,4)

sheet=Image.new('RGB',(1920,1080))
for k in range(4):
    p=Image.open(OUT/f'card-{k+1}.jpg').resize((960,540),Image.Resampling.LANCZOS)
    sheet.paste(p,((k%2)*960,(k//2)*540))
sheet.save(OUT/'masterclass-ending-review.jpg',quality=95)
# Phone-scale proof: each whole 16:9 frame, not an unsafe automatic crop.
mobile=Image.new('RGB',(390,4*220),(3,8,21))
for k in range(4):
    p=Image.open(OUT/f'card-{k+1}.jpg').resize((390,219),Image.Resampling.LANCZOS)
    mobile.paste(p,(0,k*220))
mobile.save(OUT/'phone-size-review.jpg',quality=95)
print('Rendered all four cards, contact sheet and 390px proof.')
